# refactored-guacamole

1. Copy the all of the files included in our system to your SCU webpages directory.
2. Navigate to http://students.engr.scu.edu/~username/home.php, replacing "username" with your username
